from flask import Flask, render_template, request, redirect, session 
app = Flask(__name__)
app.secret_key = 'slkjdflkjs'


@app.route('/')
def start():
    import random 
    if "number" not in session: 
        session["number"]= random.randint(1,100)
    
    display = {
        "message": None
    }

    if "game" not in session: 
        display["message"] = "Take a guess!"
    elif session["game"] > session["number"]:
        display["message"] = "Too high!"
    elif session["game"] < session["number"]:
        display["message"] = "Too low!"
    elif session["game"] == session["number"]: 
        display["message"] = "You guessed correctly!"

    if "guesses" not in session: 
        session['guesses'] = 0
    
    return render_template("index.html", messages=display)


@app.route('/playing', methods=["POST"])
def playing():
    session["game"] = int(request.form["game"])
    session["guesses"] = session["guesses"]+1
    return redirect('/')


@app.route('/restart')
def restart():
    session.clear() 
    return redirect('/')

    
if __name__ == "__main__":
    app.run(debug=True)